/**
 * CCLinkForge Pro - Web Application Controller
 */

document.addEventListener('DOMContentLoaded', function () {
  // Navigation Tabs
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      tabBtns.forEach(b => b.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));

      btn.classList.add('active');
      const targetId = btn.getAttribute('data-tab');
      document.getElementById(targetId).classList.add('active');
    });
  });

  // Default Stations Dataset
  let stations = [
    { stationNo: 1, name: 'Robotic Welding Arm', rxPoints: 64, ryPoints: 64, rwwPoints: 16, rwrPoints: 16 },
    { stationNo: 2, name: 'High-Precision Servo Gantry', rxPoints: 32, ryPoints: 32, rwwPoints: 32, rwrPoints: 32 },
    { stationNo: 3, name: 'Pneumatic Valve Island', rxPoints: 128, ryPoints: 128, rwwPoints: 8, rwrPoints: 8 },
    { stationNo: 4, name: 'Cognex Vision Scanner', rxPoints: 32, ryPoints: 32, rwwPoints: 72, rwrPoints: 72 }
  ];

  // TAB 1: SLMP Frame Builder
  const slmpCmdSelect = document.getElementById('slmp-cmd');
  const groupWriteData = document.getElementById('group-write-data');

  slmpCmdSelect.addEventListener('change', () => {
    if (slmpCmdSelect.value.includes('WRITE')) {
      groupWriteData.style.display = 'block';
    } else {
      groupWriteData.style.display = 'none';
    }
  });

  function renderSLMPFrame() {
    const netNo = parseInt(document.getElementById('slmp-net').value) || 1;
    const stnNo = parseInt(document.getElementById('slmp-stn').value) || 1;
    const cmdKey = document.getElementById('slmp-cmd').value;
    const devType = document.getElementById('slmp-dev').value;
    const headAddr = parseInt(document.getElementById('slmp-head').value) || 0;
    const points = parseInt(document.getElementById('slmp-points').value) || 16;

    const cmdInfo = CCLinkEngine.COMMANDS[cmdKey] || CCLinkEngine.COMMANDS.DEVICE_READ;

    let writeData = [];
    if (cmdKey.includes('WRITE')) {
      const valsStr = document.getElementById('slmp-write-vals').value;
      writeData = valsStr.split(',').map(s => parseInt(s.trim()) || 0);
    }

    const frame = CCLinkEngine.buildSLMPBinaryFrame({
      networkNo: netNo,
      stationNo: stnNo,
      command: cmdInfo.cmd,
      subCommand: cmdInfo.sub,
      deviceCode: devType,
      headAddress: headAddr,
      points: points,
      writeData: writeData
    });

    document.getElementById('slmp-hex-output').innerText = frame.hexString;
    document.getElementById('slmp-byte-len').innerText = `${frame.length} Bytes`;

    // Render Dissection Table
    const tbody = document.getElementById('dissection-tbody');
    tbody.innerHTML = `
      <tr><td>Subheader</td><td>${frame.parsedMeta.subHeader}</td><td>3E Binary Request Frame</td></tr>
      <tr><td>Network No</td><td>${frame.parsedMeta.networkNo}</td><td>Target Network ID</td></tr>
      <tr><td>Station No</td><td>${frame.parsedMeta.stationNo}</td><td>Target Station ID</td></tr>
      <tr><td>Module I/O No</td><td>${frame.parsedMeta.moduleIONo}</td><td>0x03FF = Own CPU Module</td></tr>
      <tr><td>Command</td><td>${frame.parsedMeta.command}</td><td>${cmdInfo.name}</td></tr>
      <tr><td>Device Code</td><td>${frame.parsedMeta.deviceCode}</td><td>${CCLinkEngine.DEVICE_CODES[frame.parsedMeta.deviceCode].name}</td></tr>
      <tr><td>Head Address</td><td>${frame.parsedMeta.headAddress} (0x${frame.parsedMeta.headAddress.toString(16).toUpperCase()})</td><td>Starting Device Register</td></tr>
      <tr><td>Points Count</td><td>${frame.parsedMeta.points}</td><td>Requested Points / Registers</td></tr>
    `;
  }

  document.getElementById('btn-build-slmp').addEventListener('click', renderSLMPFrame);
  document.getElementById('btn-sample-dissect').addEventListener('click', () => {
    document.getElementById('slmp-cmd').value = 'DEVICE_READ';
    document.getElementById('slmp-dev').value = 'RWr';
    document.getElementById('slmp-head').value = '0';
    document.getElementById('slmp-points').value = '32';
    renderSLMPFrame();
  });

  // TAB 2: Station Matrix Rendering
  function renderStationTable() {
    const tbody = document.getElementById('tbody-stations');
    tbody.innerHTML = '';
    stations.forEach((st, idx) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><input type="number" class="form-control" style="width: 70px;" value="${st.stationNo}" onchange="updateStation(${idx}, 'stationNo', this.value)"></td>
        <td><input type="text" class="form-control" value="${st.name}" onchange="updateStation(${idx}, 'name', this.value)"></td>
        <td><input type="number" class="form-control" style="width: 80px;" value="${st.rxPoints}" onchange="updateStation(${idx}, 'rxPoints', this.value)"></td>
        <td><input type="number" class="form-control" style="width: 80px;" value="${st.ryPoints}" onchange="updateStation(${idx}, 'ryPoints', this.value)"></td>
        <td><input type="number" class="form-control" style="width: 80px;" value="${st.rwwPoints}" onchange="updateStation(${idx}, 'rwwPoints', this.value)"></td>
        <td><input type="number" class="form-control" style="width: 80px;" value="${st.rwrPoints}" onchange="updateStation(${idx}, 'rwrPoints', this.value)"></td>
        <td><button class="btn btn-secondary" style="padding: 4px 8px; color: var(--rose-accent);" onclick="removeStation(${idx})">✕</button></td>
      `;
      tbody.appendChild(tr);
    });

    renderMatrixResult();
  }

  window.updateStation = function (idx, field, val) {
    if (field === 'name') {
      stations[idx][field] = val;
    } else {
      stations[idx][field] = parseInt(val) || 0;
    }
    renderMatrixResult();
  };

  window.removeStation = function (idx) {
    if (stations.length > 1) {
      stations.splice(idx, 1);
      renderStationTable();
    }
  };

  document.getElementById('btn-add-station').addEventListener('click', () => {
    const nextNo = stations.length + 1;
    stations.push({
      stationNo: nextNo,
      name: `Station ${nextNo} Device`,
      rxPoints: 32,
      ryPoints: 32,
      rwwPoints: 16,
      rwrPoints: 16
    });
    renderStationTable();
  });

  function renderMatrixResult() {
    const allocResult = CCLinkMatrix.generateLinkAllocation(stations);
    const tbody = document.getElementById('tbody-matrix-result');
    tbody.innerHTML = '';

    allocResult.allocations.forEach(a => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>Stn ${a.stationNo}</strong> (${a.name})</td>
        <td>${a.rx.points > 0 ? `${a.rx.start} .. ${a.rx.end} (${a.rx.points} pts)` : 'None'}</td>
        <td>${a.ry.points > 0 ? `${a.ry.start} .. ${a.ry.end} (${a.ry.points} pts)` : 'None'}</td>
        <td>${a.rww.points > 0 ? `${a.rww.start} .. ${a.rww.end} (${a.rww.points} w)` : 'None'}</td>
        <td>${a.rwr.points > 0 ? `${a.rwr.start} .. ${a.rwr.end} (${a.rwr.points} w)` : 'None'}</td>
      `;
      tbody.appendChild(tr);
    });

    // Update Sizer defaults with actual totals
    document.getElementById('sizer-stations').value = allocResult.summary.totalStations;
    document.getElementById('sizer-bits').value = allocResult.summary.totalRxBits + allocResult.summary.totalRyBits;
    document.getElementById('sizer-words').value = allocResult.summary.totalRwwWords + allocResult.summary.totalRwrWords;
    recalculateSizer();
  }

  // TAB 3: Recalculate Sizer
  function recalculateSizer() {
    const stnCount = parseInt(document.getElementById('sizer-stations').value) || 4;
    const totalBits = parseInt(document.getElementById('sizer-bits').value) || 256;
    const totalWords = parseInt(document.getElementById('sizer-words').value) || 128;
    const cableMeters = parseInt(document.getElementById('sizer-cable').value) || 180;

    const res = CCLinkMatrix.calculateLinkScanTime(stnCount, totalBits / 2, totalBits / 2, totalWords / 2, totalWords / 2, cableMeters);

    document.getElementById('stat-scan-time').innerText = `${res.scanTimeMs.toFixed(2)} ms`;
    document.getElementById('stat-refresh-rate').innerText = `${res.maxRefreshHz.toLocaleString()} Hz`;
    document.getElementById('stat-bandwidth').innerText = `${res.utilizationPercent.toFixed(2)} %`;

    const badge = document.getElementById('sizer-status-badge');
    badge.innerText = res.status.replace('_', ' ');
    if (res.isSubMillisecond) {
      badge.style.borderColor = 'var(--emerald-accent)';
      badge.style.color = 'var(--emerald-accent)';
    } else {
      badge.style.borderColor = 'var(--amber-accent)';
      badge.style.color = 'var(--amber-accent)';
    }
  }

  document.getElementById('btn-recalc-sizer').addEventListener('click', recalculateSizer);

  // TAB 4: 10-Point Safety Auditor
  function runAudit() {
    const stnCount = stations.length;
    const sizerScanTime = parseFloat(document.getElementById('stat-scan-time').innerText) || 0.38;

    const auditRes = CCLinkAuditor.auditNetwork({
      stations: stations,
      cableLengths: [45, 60, 35, 40],
      ringEnabled: true,
      scanTimeMs: sizerScanTime,
      slmpTimerMs: 4000
    });

    document.getElementById('audit-score').innerText = `${auditRes.summary.overallScore}/100`;
    document.getElementById('audit-grade').innerText = auditRes.summary.grade;
    document.getElementById('audit-summary-counts').innerText =
      `${auditRes.summary.passCount} Pass / ${auditRes.summary.warnCount} Warn / ${auditRes.summary.failCount} Fail`;

    const container = document.getElementById('audit-results-container');
    container.innerHTML = '';

    auditRes.findings.forEach(f => {
      const rule = auditRes.rules.find(r => r.id === f.id);
      const item = document.createElement('div');
      item.className = 'audit-item';

      let statusClass = 'audit-pass';
      if (f.status === 'WARN') statusClass = 'audit-warn';
      if (f.status === 'FAIL') statusClass = 'audit-fail';

      item.innerHTML = `
        <span class="audit-status ${statusClass}">${f.status}</span>
        <div class="audit-content">
          <h4>[${f.id}] ${rule ? rule.name : f.id} (${rule ? rule.standard : 'STD'})</h4>
          <p>${f.details}</p>
        </div>
      `;
      container.appendChild(item);
    });
  }

  document.getElementById('btn-run-audit').addEventListener('click', runAudit);

  // TAB 5: Exporter
  document.getElementById('btn-generate-export').addEventListener('click', () => {
    const fmt = document.getElementById('export-format').value;
    const alloc = CCLinkMatrix.generateLinkAllocation(stations);
    let output = '';

    if (fmt === 'GXWORKS3_CSV') {
      output = `// GX Works3 CC-Link IE Field Network Parameters\n`;
      output += `Station_No,Station_Name,RX_Start,RX_End,RY_Start,RY_End,RWw_Start,RWw_End,RWr_Start,RWr_End\n`;
      alloc.allocations.forEach(a => {
        output += `${a.stationNo},"${a.name}",${a.rx.start},${a.rx.end},${a.ry.start},${a.ry.end},${a.rww.start},${a.rww.end},${a.rwr.start},${a.rwr.end}\n`;
      });
    } else if (fmt === 'IEC_ST') {
      output = `(* IEC 61131-3 Structured Text Global CC-Link IE Link Registers *)\nVAR_GLOBAL\n`;
      alloc.allocations.forEach(a => {
        output += `  (* Station ${a.stationNo}: ${a.name} *)\n`;
        output += `  stn${a.stationNo}_Inputs AT %IX${a.stationNo}.0 : ARRAY[0..${Math.max(1, a.rx.points - 1)}] OF BOOL;\n`;
        output += `  stn${a.stationNo}_Outputs AT %QX${a.stationNo}.0 : ARRAY[0..${Math.max(1, a.ry.points - 1)}] OF BOOL;\n`;
        output += `  stn${a.stationNo}_Setpoints AT %QW${a.stationNo}.0 : ARRAY[0..${Math.max(1, a.rww.points - 1)}] OF INT;\n`;
        output += `  stn${a.stationNo}_Actuals AT %IW${a.stationNo}.0 : ARRAY[0..${Math.max(1, a.rwr.points - 1)}] OF INT;\n\n`;
      });
      output += `END_VAR\n`;
    } else if (fmt === 'PYTHON_SLMP') {
      output = `# Python SLMP Client for CC-Link IE Field Network\nimport socket\n\n`;
      output += `def read_cclink_rwr(host='192.168.3.250', port=45237, stn=1, points=16):\n`;
      output += `    # SLMP 3E Binary Request: Batch Read RWr\n`;
      output += `    frame = bytes([0x50, 0x00, 0x01, stn, 0xFF, 0x03, 0x00, 0x0C, 0x00, 0x10, 0x00, 0x01, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0xB5, points & 0xFF, (points >> 8) & 0xFF])\n`;
      output += `    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)\n`;
      output += `    sock.settimeout(2.0)\n`;
      output += `    sock.sendto(frame, (host, port))\n`;
      output += `    resp, _ = sock.recvfrom(2048)\n`;
      output += `    return resp\n\n`;
      output += `print("Reading Station 1 RWr registers via SLMP...")\n`;
    }

    document.getElementById('export-output').value = output;
  });

  // Export Matrix CSV
  document.getElementById('btn-export-matrix-csv').addEventListener('click', () => {
    const alloc = CCLinkMatrix.generateLinkAllocation(stations);
    let csv = `Station_No,Station_Name,RX_Start,RX_End,Points_RX,RY_Start,RY_End,Points_RY,RWw_Start,RWw_End,Words_RWw,RWr_Start,RWr_End,Words_RWr\n`;
    alloc.allocations.forEach(a => {
      csv += `${a.stationNo},"${a.name}",${a.rx.start},${a.rx.end},${a.rx.points},${a.ry.start},${a.ry.end},${a.ry.points},${a.rww.start},${a.rww.end},${a.rww.points},${a.rwr.start},${a.rwr.end},${a.rwr.points}\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'cclink_link_matrix.csv';
    a.click();
    URL.revokeObjectURL(url);
  });

  // Initialize
  renderSLMPFrame();
  renderStationTable();
  recalculateSizer();
  runAudit();
});
