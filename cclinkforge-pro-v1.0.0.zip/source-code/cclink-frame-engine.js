/**
 * CCLinkForge Pro - CC-Link IE Field & SLMP Frame Engine
 * Implements Seamless Message Protocol (SLMP) / MC Protocol 3E Frame Encoding,
 * Decoding, Verification, and Cyclic Link Mapping (RX/RY/RWw/RWr).
 */

const CCLinkEngine = (function () {
  // SLMP Device Codes for CC-Link IE & Mitsubishi iQ-R/Q Series
  const DEVICE_CODES = {
    RX: { code: 0x9c, type: 'bit', radix: 16, name: 'Remote Input (RX)' },
    RY: { code: 0x9d, type: 'bit', radix: 16, name: 'Remote Output (RY)' },
    RWw: { code: 0xb4, type: 'word', radix: 16, name: 'Remote Register Write (RWw)' },
    RWr: { code: 0xb5, type: 'word', radix: 16, name: 'Remote Register Read (RWr)' },
    M: { code: 0x90, type: 'bit', radix: 10, name: 'Internal Relay (M)' },
    X: { code: 0x9c, type: 'bit', radix: 16, name: 'Input Relay (X)' },
    Y: { code: 0x9d, type: 'bit', radix: 16, name: 'Output Relay (Y)' },
    D: { code: 0xa8, type: 'word', radix: 10, name: 'Data Register (D)' },
    W: { code: 0xb4, type: 'word', radix: 16, name: 'Link Register (W)' },
    B: { code: 0xa0, type: 'bit', radix: 16, name: 'Link Relay (B)' },
    ZR: { code: 0xb0, type: 'word', radix: 16, name: 'File Register (ZR)' }
  };

  const COMMANDS = {
    DEVICE_READ: { cmd: 0x0401, sub: 0x0000, name: 'Device Batch Read (Word Units)' },
    DEVICE_READ_BIT: { cmd: 0x0401, sub: 0x0001, name: 'Device Batch Read (Bit Units)' },
    DEVICE_WRITE: { cmd: 0x1401, sub: 0x0000, name: 'Device Batch Write (Word Units)' },
    DEVICE_WRITE_BIT: { cmd: 0x1401, sub: 0x0001, name: 'Device Batch Write (Bit Units)' },
    ARRAY_READ: { cmd: 0x0403, sub: 0x0000, name: 'Block Read' },
    ARRAY_WRITE: { cmd: 0x1403, sub: 0x0000, name: 'Block Write' },
    LOOP_TEST: { cmd: 0x0619, sub: 0x0000, name: 'Self-Diagnostic Echo / Loop Test' }
  };

  /**
   * Builds an SLMP / 3E Frame (Binary format).
   */
  function buildSLMPBinaryFrame(options) {
    const opts = Object.assign({
      subHeader: 0x5000, // 3E Binary Request
      networkNo: 1,      // 0x01
      stationNo: 1,      // 0x01
      moduleIONo: 0x03ff,// 0x03FF = Own station CPU
      multidropNo: 0x00, // 0x00
      monitoringTimer: 16,// 16 * 250ms = 4s (in 250ms units)
      command: 0x0401,   // Batch Read
      subCommand: 0x0000,
      deviceCode: 'RX',
      headAddress: 0,
      points: 8,
      writeData: []      // Word array or bit array for write commands
    }, options);

    const devMeta = DEVICE_CODES[opts.deviceCode] || DEVICE_CODES.RX;
    const reqData = [];

    if (opts.command === 0x0619) {
      // Loop test: 2-byte loop data length + loop data
      const echoStr = opts.echoString || 'CCLinkForgePro';
      reqData.push(echoStr.length & 0xff, (echoStr.length >> 8) & 0xff);
      for (let i = 0; i < echoStr.length; i++) {
        reqData.push(echoStr.charCodeAt(i));
      }
    } else {
      // Device Command Payload:
      // Head Device Number: 3 bytes (little endian: low, mid, high)
      reqData.push(opts.headAddress & 0xff);
      reqData.push((opts.headAddress >> 8) & 0xff);
      reqData.push((opts.headAddress >> 16) & 0xff);
      // Device Code: 1 byte
      reqData.push(devMeta.code);
      // Number of points: 2 bytes (little endian)
      reqData.push(opts.points & 0xff);
      reqData.push((opts.points >> 8) & 0xff);

      // If Write Command, append write data payload
      if (opts.command === 0x1401) {
        if (opts.subCommand === 0x0001) {
          // Bit write: 1 nibble per bit, packed 2 bits per byte
          const bits = opts.writeData || [];
          for (let i = 0; i < opts.points; i += 2) {
            const b1 = (bits[i] ? 1 : 0) << 4;
            const b2 = (bits[i + 1] ? 1 : 0) & 0x0f;
            reqData.push(b1 | b2);
          }
        } else {
          // Word write: 2 bytes per word
          const words = opts.writeData || [];
          for (let i = 0; i < opts.points; i++) {
            const val = words[i] || 0;
            reqData.push(val & 0xff);
            reqData.push((val >> 8) & 0xff);
          }
        }
      }
    }

    // Monitoring timer: 2 bytes
    const timerBytes = [opts.monitoringTimer & 0xff, (opts.monitoringTimer >> 8) & 0xff];
    // Command & Subcommand: 2 + 2 bytes
    const cmdBytes = [
      opts.command & 0xff, (opts.command >> 8) & 0xff,
      opts.subCommand & 0xff, (opts.subCommand >> 8) & 0xff
    ];

    // Request Data Length = 2 (timer) + 4 (cmd+sub) + reqData.length
    const reqDataLength = timerBytes.length + cmdBytes.length + reqData.length;

    const frameBytes = [
      // Subheader (2 bytes, little-endian)
      opts.subHeader & 0xff, (opts.subHeader >> 8) & 0xff,
      // Network No (1 byte)
      opts.networkNo & 0xff,
      // Station No (1 byte)
      opts.stationNo & 0xff,
      // Request Module I/O No (2 bytes)
      opts.moduleIONo & 0xff, (opts.moduleIONo >> 8) & 0xff,
      // Request Multidrop Station No (1 byte)
      opts.multidropNo & 0xff,
      // Request Data Length (2 bytes)
      reqDataLength & 0xff, (reqDataLength >> 8) & 0xff,
      // Monitoring Timer (2 bytes)
      ...timerBytes,
      // Command & Subcommand (4 bytes)
      ...cmdBytes,
      // Request Data
      ...reqData
    ];

    const hexString = frameBytes.map(b => b.toString(16).padStart(2, '0').toUpperCase()).join(' ');

    return {
      frameBytes,
      hexString,
      length: frameBytes.length,
      protocol: 'SLMP / CC-Link IE Field 3E Binary',
      parsedMeta: {
        subHeader: `0x${opts.subHeader.toString(16).padStart(4, '0').toUpperCase()}`,
        networkNo: opts.networkNo,
        stationNo: opts.stationNo,
        moduleIONo: `0x${opts.moduleIONo.toString(16).padStart(4, '0').toUpperCase()}`,
        command: `0x${opts.command.toString(16).padStart(4, '0').toUpperCase()}`,
        deviceCode: opts.deviceCode,
        headAddress: opts.headAddress,
        points: opts.points
      }
    };
  }

  /**
   * Dissects an incoming SLMP 3E Binary frame.
   */
  function dissectSLMPBinaryFrame(hexOrBytes) {
    let bytes = [];
    if (typeof hexOrBytes === 'string') {
      const cleanHex = hexOrBytes.replace(/[^0-9a-fA-F]/g, '');
      for (let i = 0; i < cleanHex.length; i += 2) {
        bytes.push(parseInt(cleanHex.substr(i, 2), 16));
      }
    } else if (Array.isArray(hexOrBytes)) {
      bytes = hexOrBytes;
    }

    if (bytes.length < 11) {
      throw new Error(`Frame truncated: minimum 3E header is 11 bytes, got ${bytes.length} bytes.`);
    }

    const subHeader = (bytes[1] << 8) | bytes[0];
    const networkNo = bytes[2];
    const stationNo = bytes[3];
    const moduleIONo = (bytes[5] << 8) | bytes[4];
    const multidropNo = bytes[6];
    const dataLength = (bytes[8] << 8) | bytes[7];

    const isResponse = (subHeader === 0xd000 || subHeader === 0xd400);

    if (!isResponse) {
      // Request Frame
      if (bytes.length < 9 + dataLength) {
        throw new Error(`Incomplete frame data: expected ${9 + dataLength} bytes, found ${bytes.length}.`);
      }
      const monitoringTimer = (bytes[10] << 8) | bytes[9];
      const command = (bytes[12] << 8) | bytes[11];
      const subCommand = (bytes[14] << 8) | bytes[13];

      let payload = {};
      if (bytes.length >= 21 && (command === 0x0401 || command === 0x1401)) {
        const headAddr = bytes[15] | (bytes[16] << 8) | (bytes[17] << 16);
        const devCodeByte = bytes[18];
        const points = bytes[19] | (bytes[20] << 8);

        let devName = 'Unknown';
        for (const [k, v] of Object.entries(DEVICE_CODES)) {
          if (v.code === devCodeByte) {
            devName = k;
            break;
          }
        }

        payload = {
          headAddress: headAddr,
          deviceCode: devName,
          deviceCodeHex: `0x${devCodeByte.toString(16).padStart(2, '0').toUpperCase()}`,
          points: points,
          writeData: bytes.slice(21)
        };
      }

      return {
        type: 'REQUEST',
        subHeader: `0x${subHeader.toString(16).padStart(4, '0').toUpperCase()}`,
        networkNo,
        stationNo,
        moduleIONo: `0x${moduleIONo.toString(16).padStart(4, '0').toUpperCase()}`,
        multidropNo,
        dataLength,
        monitoringTimer: monitoringTimer * 250 + ' ms',
        command: `0x${command.toString(16).padStart(4, '0').toUpperCase()}`,
        subCommand: `0x${subCommand.toString(16).padStart(4, '0').toUpperCase()}`,
        payload,
        rawBytesCount: bytes.length
      };
    } else {
      // Response Frame
      const endCode = (bytes[10] << 8) | bytes[9];
      const responseData = bytes.slice(11);
      return {
        type: 'RESPONSE',
        subHeader: `0x${subHeader.toString(16).padStart(4, '0').toUpperCase()}`,
        networkNo,
        stationNo,
        moduleIONo: `0x${moduleIONo.toString(16).padStart(4, '0').toUpperCase()}`,
        multidropNo,
        dataLength,
        endCode: `0x${endCode.toString(16).padStart(4, '0').toUpperCase()}`,
        isSuccess: endCode === 0,
        responseData,
        rawBytesCount: bytes.length
      };
    }
  }

  return {
    DEVICE_CODES,
    COMMANDS,
    buildSLMPBinaryFrame,
    dissectSLMPBinaryFrame
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = CCLinkEngine;
}
