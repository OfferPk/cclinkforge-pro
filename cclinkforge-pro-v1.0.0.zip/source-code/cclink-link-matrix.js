/**
 * CCLinkForge Pro - CC-Link IE Field Link Matrix & Cyclic Sizer Engine
 * Calculates Station Bit/Word link mappings (RX, RY, RWw, RWr),
 * memory offsets, cyclic transmission timings, and bandwidth utilization.
 */

const CCLinkMatrix = (function () {
  /**
   * Generates Station Cyclic Device Mapping Table
   * @param {Array} stations - Array of station objects:
   *   { stationNo, name, rxPoints, ryPoints, rwwPoints, rwrPoints }
   */
  function generateLinkAllocation(stations) {
    let currentRxOffset = 0x0000;
    let currentRyOffset = 0x0000;
    let currentRwwOffset = 0x0000;
    let currentRwrOffset = 0x0000;

    const allocations = [];
    let totalRxBits = 0;
    let totalRyBits = 0;
    let totalRwwWords = 0;
    let totalRwrWords = 0;

    // Sort stations by station number
    const sortedStations = [...stations].sort((a, b) => a.stationNo - b.stationNo);

    for (const st of sortedStations) {
      const rxPts = parseInt(st.rxPoints) || 0;
      const ryPts = parseInt(st.ryPoints) || 0;
      const rwwPts = parseInt(st.rwwPoints) || 0;
      const rwrPts = parseInt(st.rwrPoints) || 0;

      const alloc = {
        stationNo: st.stationNo,
        name: st.name || `Station ${st.stationNo}`,
        rx: {
          points: rxPts,
          start: `RX${currentRxOffset.toString(16).toUpperCase().padStart(4, '0')}`,
          end: rxPts > 0 ? `RX${(currentRxOffset + rxPts - 1).toString(16).toUpperCase().padStart(4, '0')}` : 'N/A',
          startHex: currentRxOffset,
          endHex: rxPts > 0 ? (currentRxOffset + rxPts - 1) : currentRxOffset
        },
        ry: {
          points: ryPts,
          start: `RY${currentRyOffset.toString(16).toUpperCase().padStart(4, '0')}`,
          end: ryPts > 0 ? `RY${(currentRyOffset + ryPts - 1).toString(16).toUpperCase().padStart(4, '0')}` : 'N/A',
          startHex: currentRyOffset,
          endHex: ryPts > 0 ? (currentRyOffset + ryPts - 1) : currentRyOffset
        },
        rww: {
          points: rwwPts,
          start: `RWw${currentRwwOffset.toString(16).toUpperCase().padStart(4, '0')}`,
          end: rwwPts > 0 ? `RWw${(currentRwwOffset + rwwPts - 1).toString(16).toUpperCase().padStart(4, '0')}` : 'N/A',
          startHex: currentRwwOffset,
          endHex: rwwPts > 0 ? (currentRwwOffset + rwwPts - 1) : currentRwwOffset
        },
        rwr: {
          points: rwrPts,
          start: `RWr${currentRwrOffset.toString(16).toUpperCase().padStart(4, '0')}`,
          end: rwrPts > 0 ? `RWr${(currentRwrOffset + rwrPts - 1).toString(16).toUpperCase().padStart(4, '0')}` : 'N/A',
          startHex: currentRwrOffset,
          endHex: rwrPts > 0 ? (currentRwrOffset + rwrPts - 1) : currentRwrOffset
        }
      };

      allocations.push(alloc);

      currentRxOffset += rxPts;
      currentRyOffset += ryPts;
      currentRwwOffset += rwwPts;
      currentRwrOffset += rwrPts;

      totalRxBits += rxPts;
      totalRyBits += ryPts;
      totalRwwWords += rwwPts;
      totalRwrWords += rwrPts;
    }

    return {
      allocations,
      summary: {
        totalStations: sortedStations.length,
        totalRxBits,
        totalRyBits,
        totalRwwWords,
        totalRwrWords,
        totalBitBytes: Math.ceil((totalRxBits + totalRyBits) / 8),
        totalWordBytes: (totalRwwWords + totalRwrWords) * 2
      }
    };
  }

  /**
   * Calculates CC-Link IE Field Link Scan Time (Tscan in microseconds/milliseconds)
   * Based on standard CLPA formula for 1Gbps Gigabit CC-Link IE Field:
   * Tscan = (Total Bit Transmission Time) + (Total Word Transmission Time) + (Station Processing Overhead)
   * Bit frame size overhead + Word frame size overhead + Token passing
   */
  function calculateLinkScanTime(stationCount, rxBits, ryBits, rwwWords, rwrWords, cableLengthMeters = 100) {
    const bitPoints = rxBits + ryBits;
    const wordPoints = rwwWords + rwrWords;
    const stations = Math.max(1, stationCount);

    // Frame transmission times at 1 Gbps (1 bit = 1 ns)
    // Frame preamble, header, payload, FCS overhead (~64 bytes = 512 bits)
    const basePreambleOverheadUs = stations * 3.2; // 3.2 us per station turn
    const bitPayloadUs = (bitPoints / 1000.0) * 0.8; // ~0.8 us per 1000 bits
    const wordPayloadUs = (wordPoints * 16 / 1000.0) * 0.8; // 16 bits per word
    const cablePropagationUs = (cableLengthMeters * 5.0) / 1000.0; // 5 ns per meter

    // Total Link Scan Time in milliseconds
    const totalUs = basePreambleOverheadUs + bitPayloadUs + wordPayloadUs + cablePropagationUs + (stations * 8.5);
    const scanTimeMs = Math.max(0.12, parseFloat((totalUs / 1000.0).toFixed(3)));

    // Maximum safe refresh rate
    const maxRefreshHz = Math.floor(1000.0 / scanTimeMs);

    // Bandwidth utilization on 1 Gbps physical link
    const cyclicBandwidthKbps = ((bitPoints + wordPoints * 16) / scanTimeMs);
    const utilizationPercent = parseFloat(((cyclicBandwidthKbps / 1000000.0) * 100.0).toFixed(2));

    return {
      scanTimeMs,
      scanTimeUs: Math.round(totalUs),
      maxRefreshHz,
      cyclicBandwidthKbps: Math.round(cyclicBandwidthKbps),
      utilizationPercent,
      isSubMillisecond: scanTimeMs < 1.0,
      status: scanTimeMs < 1.0 ? 'OPTIMAL_REALTIME' : (scanTimeMs < 5.0 ? 'STANDARD_CYCLIC' : 'HIGH_LATENCY')
    };
  }

  return {
    generateLinkAllocation,
    calculateLinkScanTime
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = CCLinkMatrix;
}
