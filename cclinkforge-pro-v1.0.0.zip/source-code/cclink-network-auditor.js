/**
 * CCLinkForge Pro - 10-Point CC-Link IE / CC-Link Network Safety Auditor
 * Validates topology, station ranges, link register bounds, loopback redundancy,
 * transmission cycle margins, and cable constraints per CLPA & IEC 61158 standards.
 */

const CCLinkAuditor = (function () {
  const AUDIT_RULES = [
    {
      id: 'CHK-01',
      name: 'Station Number Range & Zero-Check',
      standard: 'CLPA BAP-0100',
      severity: 'CRITICAL',
      description: 'Station numbers must be contiguous or valid integers between 1 and 120 (0 is reserved for Master).'
    },
    {
      id: 'CHK-02',
      name: 'Station Number Collision Detection',
      standard: 'CLPA BAP-0105',
      severity: 'CRITICAL',
      description: 'Duplicate station IDs cause bus collision, link halt, or diagnostic error 0xF010.'
    },
    {
      id: 'CHK-03',
      name: 'Max Station Count Limit',
      standard: 'IEC 61158 CC-Link IE Field',
      severity: 'ERROR',
      description: 'Maximum allowable stations per network segment is 120 (plus 1 master station).'
    },
    {
      id: 'CHK-04',
      name: 'Bit Device Memory Boundary (RX/RY)',
      standard: 'CLPA Profile Spec',
      severity: 'ERROR',
      description: 'Total RX and RY bit points must not exceed 16,384 bits (2,048 bytes) per master.'
    },
    {
      id: 'CHK-05',
      name: 'Word Device Memory Boundary (RWw/RWr)',
      standard: 'CLPA Profile Spec',
      severity: 'ERROR',
      description: 'Total RWw and RWr word registers must not exceed 8,192 words (16,384 bytes) per master.'
    },
    {
      id: 'CHK-06',
      name: 'Inter-Station Cable Distance Constraint',
      standard: 'IEEE 802.3ab / Cat5e/6',
      severity: 'WARNING',
      description: 'Maximum copper segment distance between adjacent nodes must not exceed 100 meters.'
    },
    {
      id: 'CHK-07',
      name: 'Ring Redundancy & Loopback Readiness',
      standard: 'CLPA IE Field Ring Spec',
      severity: 'WARNING',
      description: 'Ring topology requires dual PHY ports (PORT1 & PORT2) connected in closed loop for sub-millisecond healing.'
    },
    {
      id: 'CHK-08',
      name: 'Sub-Millisecond Determinism Margin',
      standard: 'Motion / Synchronized Profile',
      severity: 'WARNING',
      description: 'Cyclic scan time should stay below 2.0 ms (ideally < 1.0 ms) to avoid PLC jitter and watchdog timeout.'
    },
    {
      id: 'CHK-09',
      name: 'Reserved Station Space Allocation',
      standard: 'Maintenance Standard',
      severity: 'INFO',
      description: 'Networks should leave 10-20% headroom in link register allocations for future node expansion.'
    },
    {
      id: 'CHK-10',
      name: 'Transient SLMP Monitoring Timer Safety',
      standard: 'SLMP Communication Spec',
      severity: 'WARNING',
      description: 'Monitoring timer must be configured to at least 4x the maximum cyclic scan time to prevent premature timeout.'
    }
  ];

  /**
   * Run the 10-Point Safety Audit
   * @param {Object} config - { stations, networkMode, cableLengths, ringEnabled, scanTimeMs, slmpTimerMs }
   */
  function auditNetwork(config) {
    const stations = config.stations || [];
    const cableLengths = config.cableLengths || [50];
    const ringEnabled = config.ringEnabled !== false;
    const scanTimeMs = config.scanTimeMs || 0.5;
    const slmpTimerMs = config.slmpTimerMs || 4000;

    const findings = [];
    let passCount = 0;
    let warnCount = 0;
    let failCount = 0;

    // CHK-01: Station Number Range & Zero-Check
    let chk01Fail = false;
    let chk01Details = [];
    stations.forEach(s => {
      const num = parseInt(s.stationNo);
      if (isNaN(num) || num < 1 || num > 120) {
        chk01Fail = true;
        chk01Details.push(`Station '${s.name || s.stationNo}' has invalid station ID: ${s.stationNo}. Range must be 1..120.`);
      }
    });
    if (chk01Fail) {
      findings.push({ id: 'CHK-01', status: 'FAIL', severity: 'CRITICAL', details: chk01Details.join(' ') });
      failCount++;
    } else {
      findings.push({ id: 'CHK-01', status: 'PASS', severity: 'INFO', details: 'All station numbers are within legitimate 1..120 range.' });
      passCount++;
    }

    // CHK-02: Duplicate Station IDs
    const stationIdSet = new Set();
    const duplicates = [];
    stations.forEach(s => {
      const num = parseInt(s.stationNo);
      if (stationIdSet.has(num)) {
        duplicates.push(num);
      } else {
        stationIdSet.add(num);
      }
    });
    if (duplicates.length > 0) {
      findings.push({ id: 'CHK-02', status: 'FAIL', severity: 'CRITICAL', details: `Duplicate station IDs detected: ${duplicates.join(', ')}. Fatal bus collision risk.` });
      failCount++;
    } else {
      findings.push({ id: 'CHK-02', status: 'PASS', severity: 'INFO', details: 'No duplicate station IDs detected. Each node has a unique bus address.' });
      passCount++;
    }

    // CHK-03: Max Station Count
    if (stations.length > 120) {
      findings.push({ id: 'CHK-03', status: 'FAIL', severity: 'ERROR', details: `Station count (${stations.length}) exceeds 120 station segment limit.` });
      failCount++;
    } else {
      findings.push({ id: 'CHK-03', status: 'PASS', severity: 'INFO', details: `Station count is ${stations.length}/120 (compliant).` });
      passCount++;
    }

    // CHK-04: Bit Device Memory Boundary (RX/RY <= 16384)
    let totalRx = 0, totalRy = 0;
    stations.forEach(s => {
      totalRx += (parseInt(s.rxPoints) || 0);
      totalRy += (parseInt(s.ryPoints) || 0);
    });
    if (totalRx > 16384 || totalRy > 16384) {
      findings.push({ id: 'CHK-04', status: 'FAIL', severity: 'ERROR', details: `Bit devices exceed 16,384 point buffer (RX: ${totalRx}, RY: ${totalRy}).` });
      failCount++;
    } else {
      findings.push({ id: 'CHK-04', status: 'PASS', severity: 'INFO', details: `RX (${totalRx}/16384) and RY (${totalRy}/16384) bit allocations within limit.` });
      passCount++;
    }

    // CHK-05: Word Device Memory Boundary (RWw/RWr <= 8192)
    let totalRww = 0, totalRwr = 0;
    stations.forEach(s => {
      totalRww += (parseInt(s.rwwPoints) || 0);
      totalRwr += (parseInt(s.rwrPoints) || 0);
    });
    if (totalRww > 8192 || totalRwr > 8192) {
      findings.push({ id: 'CHK-05', status: 'FAIL', severity: 'ERROR', details: `Word devices exceed 8,192 word buffer (RWw: ${totalRww}, RWr: ${totalRwr}).` });
      failCount++;
    } else {
      findings.push({ id: 'CHK-05', status: 'PASS', severity: 'INFO', details: `RWw (${totalRww}/8192) and RWr (${totalRwr}/8192) registers within limit.` });
      passCount++;
    }

    // CHK-06: Cable Distance Constraint
    const maxCable = Math.max(...cableLengths, 0);
    if (maxCable > 100) {
      findings.push({ id: 'CHK-06', status: 'WARN', severity: 'WARNING', details: `Longest segment (${maxCable}m) exceeds 100m Cat5e standard. Signal degradation possible.` });
      warnCount++;
    } else {
      findings.push({ id: 'CHK-06', status: 'PASS', severity: 'INFO', details: `Maximum cable segment (${maxCable}m) compliant with standard 100m Cat5e/6.` });
      passCount++;
    }

    // CHK-07: Ring Redundancy & Loopback Readiness
    if (!ringEnabled) {
      findings.push({ id: 'CHK-07', status: 'WARN', severity: 'WARNING', details: 'Line/Star topology configured without loopback ring. Cable cut will isolate downstream nodes.' });
      warnCount++;
    } else {
      findings.push({ id: 'CHK-07', status: 'PASS', severity: 'INFO', details: 'Ring topology with automatic loopback redundancy enabled.' });
      passCount++;
    }

    // CHK-08: Sub-Millisecond Determinism Margin
    if (scanTimeMs > 2.0) {
      findings.push({ id: 'CHK-08', status: 'WARN', severity: 'WARNING', details: `Cyclic scan time (${scanTimeMs} ms) exceeds 2.0 ms threshold. Realtime motion coordination restricted.` });
      warnCount++;
    } else {
      findings.push({ id: 'CHK-08', status: 'PASS', severity: 'INFO', details: `Scan time is deterministic at ${scanTimeMs} ms (High-speed cyclic).` });
      passCount++;
    }

    // CHK-09: Headroom Capacity Check
    const rxUtilization = (totalRx / 16384) * 100;
    const rwwUtilization = (totalRww / 8192) * 100;
    if (rxUtilization > 85 || rwwUtilization > 85) {
      findings.push({ id: 'CHK-09', status: 'WARN', severity: 'WARNING', details: `Memory allocation high: RX=${rxUtilization.toFixed(1)}%, RWw=${rwwUtilization.toFixed(1)}%. <15% expansion headroom.` });
      warnCount++;
    } else {
      findings.push({ id: 'CHK-09', status: 'PASS', severity: 'INFO', details: `Memory headroom ample (RX: ${rxUtilization.toFixed(1)}% used, RWw: ${rwwUtilization.toFixed(1)}% used).` });
      passCount++;
    }

    // CHK-10: Transient SLMP Monitoring Timer Safety
    const minSafeTimerMs = Math.ceil(scanTimeMs * 4);
    if (slmpTimerMs < minSafeTimerMs) {
      findings.push({ id: 'CHK-10', status: 'WARN', severity: 'WARNING', details: `SLMP Monitoring Timer (${slmpTimerMs}ms) is too aggressive (<4x scan time ${minSafeTimerMs}ms).` });
      warnCount++;
    } else {
      findings.push({ id: 'CHK-10', status: 'PASS', severity: 'INFO', details: `SLMP Monitoring Timer (${slmpTimerMs}ms) provides sufficient safety margin.` });
      passCount++;
    }

    const overallScore = Math.max(0, 100 - (failCount * 25) - (warnCount * 10));
    const grade = overallScore >= 90 ? 'A (INDUSTRIAL CERTIFIED)' : (overallScore >= 75 ? 'B (ACCEPTABLE WITH WARNINGS)' : 'C (ACTION REQUIRED)');

    return {
      rules: AUDIT_RULES,
      findings,
      summary: {
        totalRules: AUDIT_RULES.length,
        passCount,
        warnCount,
        failCount,
        overallScore,
        grade
      }
    };
  }

  return {
    AUDIT_RULES,
    auditNetwork
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = CCLinkAuditor;
}
