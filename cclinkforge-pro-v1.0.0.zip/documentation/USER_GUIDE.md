# CCLinkForge Pro - User Guide & Operator Manual

## 1. Quick Start
To launch the interactive web studio:
1. Open `product_195/source-code/index.html` in any modern web browser (Chrome, Firefox, Safari, Edge).
2. All components execute client-side with zero external internet dependencies or backend server requirements.

To use the standalone Python CLI:
```bash
# Display CLI help
./product_195/build/cclink-cli.py --help

# Generate an SLMP 3E Binary Read Frame for Station 2 Remote Register Read (RWr)
./product_195/build/cclink-cli.py slmp-build --net 1 --stn 2 --cmd read --dev RWr --head 0 --points 32

# Dissect a raw hex frame
./product_195/build/cclink-cli.py slmp-dissect "50000101FF03000C001000010400000000009C1000"

# Run the 10-Point Industrial Network Safety Auditor
./product_195/build/cclink-cli.py audit --stations '[{"station":1,"rx":64,"ry":64,"rww":16,"rwr":16},{"station":2,"rx":32,"ry":32,"rww":32,"rwr":32}]'
```

---

## 2. Workbench Tabs & Capabilities

### Tab 1: SLMP Frame Builder & Dissector
- **Command Selection**: Batch Read (0x0401), Batch Write (0x1401), or Echo Test (0x0619).
- **Target Device Selection**: Remote Inputs (`RX`), Remote Outputs (`RY`), Remote Write Registers (`RWw`), Remote Read Registers (`RWr`), Data Registers (`D`), or Link Relays (`B`).
- **Inspection**: View raw byte arrays, formatted hex streams, and step-by-step header dissection (Subheader, Network No, Station No, Module I/O, Data Length, Timer, Command, Device Code).

### Tab 2: Cyclic Link Matrix (RX/RY/RWw/RWr)
- Add, edit, or delete remote I/O stations.
- Automatically calculates contiguous non-overlapping hexadecimal address offsets (e.g. `RX0000 .. RX003F`, followed by `RX0040 .. RX005F`).
- Export entire allocation table to formatted CSV for direct import into PLC engineering software.

### Tab 3: Link Scan & Bandwidth Sizer
- Enter total stations, total bit points, total word registers, and segment cable lengths.
- Real-time readout of Link Scan Time ($T_{\text{scan}}$ in ms and $\mu\text{s}$), deterministic refresh rate in Hz, and 1 Gbps link utilization percentage.

### Tab 4: 10-Point Safety Auditor
- Evaluates the network against all 10 CLPA rules (Station range, collisions, memory buffers, cable limits, loopback redundancy, determinism, and SLMP timeouts).
- Provides instant numeric score (0..100) and certification tier (A, B, C).

### Tab 5: Mitsubishi / PLC Exporter
- Generates GX Works3 parameter tables, IEC 61131-3 Structured Text global device blocks, and Python socket automation scripts.
