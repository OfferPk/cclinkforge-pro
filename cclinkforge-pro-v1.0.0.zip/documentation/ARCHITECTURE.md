# CCLinkForge Pro - Technical Architecture & Engineering Specification

## 1. Executive Summary & Purpose
**CCLinkForge Pro** is an industrial automation protocol engineering suite specifically targeted at **CC-Link IE Field**, **CC-Link IE TSN**, and legacy **CC-Link (IEC 61158 / CLPA)** networks. It eliminates engineering trial-and-error by combining:
1. **Seamless Message Protocol (SLMP / MC Protocol 3E/4E) Frame Engine**: Real-time binary/ASCII request framing and response packet dissection over UDP/IP (port 45237) and TCP/IP.
2. **Deterministic Cyclic Memory Allocator**: Automatically calculates station-by-station memory spans for remote bit inputs (`RX`), remote bit outputs (`RY`), remote register writes (`RWw`), and remote register reads (`RWr`).
3. **Gigabit Link Scan & Bandwidth Sizer**: Analyzes physical topologies, cable propagation delay (5 ns/m), preamble overheads, and token passing times to compute sub-millisecond scan times ($T_{\text{scan}} < 1.0\text{ ms}$) and jitter bounds.
4. **10-Point Industrial Network Safety Auditor**: Evaluates topologies against official CLPA (CC-Link Partner Association) guidelines, detecting station address collisions, memory overflow, missing loopback ring redundancy, and cable overruns.
5. **Multi-Target Exporter**: Outputs GX Works3 configuration tables, IEC 61131-3 Structured Text global device blocks, and Python automation clients.

---

## 2. Protocol Standards & Compliance
- **CLPA BAP-0100 / BAP-0105**: Basic Profile and Station Numbering constraints.
- **IEC 61158-4-19 / IEC 61158-5-19 / IEC 61158-6-19**: CC-Link Fieldbus Specifications.
- **SLMP (Seamless Message Protocol)**: Specification v1.1.0 (QnA-compatible 3E Frame format).
- **Physical Layer**: IEEE 802.3ab (1000BASE-T Gigabit Ethernet), Cat5e/6 STP, max 100m inter-station distance, dual-port RJ45 PHY (PORT1 / PORT2) with auto-MDI/MDI-X.

---

## 3. Core Architecture & Component Diagram

```
+-----------------------------------------------------------------------------------+
|                                 CCLinkForge Pro                                   |
+-----------------------------------------------------------------------------------+
| [SLMP 3E/4E Frame Engine]        [Cyclic Link Sizer]       [10-Point Auditor]     |
|   • Subheader 0x5000/0xD000        • RX / RY Bit Alloc       • CHK-01..10 Checks  |
|   • Cmd 0x0401/0x1401/0x0619       • RWw / RWr Registers     • Topology Audit     |
|   • Little-Endian Serializer       • Tscan Math Modeling     • Loopback Ring Eval |
+-----------------------------------------------------------------------------------+
                                          |
                      +-------------------+-------------------+
                      |                                       |
                      v                                       v
          [Responsive Web Studio]                 [Standalone Python CLI]
          • index.html (5 Tabbed Panes)           • cclink-cli.py
          • Dark Obsidian Industrial UI           • slmp-build / dissect
          • Live SVG Diagrams & CSV export        • link-calc / audit
```

---

## 4. Cyclic Transmission Math Model

The cyclic transmission scan time ($T_{\text{scan}}$) at 1 Gbps Gigabit speed is derived using the CLPA determinism formula:

$$T_{\text{scan}} = \sum_{i=1}^{N} \left( T_{\text{station\_overhead}} + T_{\text{bit\_payload}} + T_{\text{word\_payload}} \right) + T_{\text{propagation}}$$

Where:
- $N$ = Number of connected slave stations ($1 \le N \le 120$)
- $T_{\text{station\_overhead}}$ = Station token processing & preamble (~$3.2\text{ }\mu\text{s}$ per node)
- $T_{\text{bit\_payload}} = \frac{N_{\text{RX}} + N_{\text{RY}}}{1000} \times 0.8\text{ }\mu\text{s}$
- $T_{\text{word\_payload}} = \frac{(N_{\text{RWw}} + N_{\text{RWr}}) \times 16}{1000} \times 0.8\text{ }\mu\text{s}$
- $T_{\text{propagation}} = L_{\text{cable}} \times 5\text{ ns/m}$
- Processing buffer overhead = $N \times 8.5\text{ }\mu\text{s}$

For a typical 4-station robotic cell with 256 bits and 128 words, $T_{\text{scan}} \approx 0.38\text{ ms}$, yielding a deterministic refresh rate exceeding $2,600\text{ Hz}$.
